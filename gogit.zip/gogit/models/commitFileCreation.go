package models

import (
	"fmt"
	"os"
	"path/filepath"
	"strconv"
)

func commitFileCreation() error {
	fmt.Println("in side the comit folder function")
	cmtSrcDir := ".gogit/commits"
	entries, err := os.ReadDir(cmtSrcDir)
	if err != nil {
		return fmt.Errorf(
			"\ncommit directory does not exist, run 'go run . init': %w",
			err,
		)
	}
	lastFolder := 0

	for _, entry := range entries {
		fmt.Println(
			"name:", entry.Name(),
			"isDir:", entry.IsDir(),
		)
		if !entry.IsDir() {
			continue
		}

		n, err := strconv.Atoi(entry.Name())
		if err == nil && n > lastFolder {
			lastFolder = n
		}
	}

	dstDir := filepath.Join(".gogit", "commits", strconv.Itoa(lastFolder+1))
	if err := os.MkdirAll(dstDir, 0755); err != nil {
		return fmt.Errorf("\nfailed to create commit folder: %w", err)
	}
	stgSrcDir := ".gogit/staging"
	stgEntries, err := os.ReadDir(stgSrcDir)
	for _, entry := range stgEntries {
		fmt.Println(
			"name:", entry.Name(),
			"isDir:", entry.IsDir(),
		)
		// if !entry.IsDir() {
		// 	continue
		// }
		source := filepath.Join(stgSrcDir, entry.Name())

		fmt.Println(source)
		destination := filepath.Join(dstDir, entry.Name())
		err := os.Rename(source, destination)
		if err != nil {
			return fmt.Errorf("\nError moving file:", err)

		}

		fmt.Println("File moved successfully")

	}
	return nil
}

// import (
// 	"fmt"
// 	"os"
// )

// func main() {
// 	source := "oldfolder/file.txt"
// 	destination := "newfolder/file.txt"

// 	err := os.Rename(source, destination)
// 	if err != nil {
// 		fmt.Println("Error moving file:", err)
// 		return
// 	}

// 	fmt.Println("File moved successfully")
// }

// *************************************************//
// package main

// import (
// 	"fmt"
// 	"os"
// 	"path/filepath"
// )

// func main() {
// 	srcDir := "source"
// 	dstDir := "destination"

// 	// Create destination directory if it doesn't exist
// 	if err := os.MkdirAll(dstDir, 0755); err != nil {
// 		panic(err)
// 	}

// 	entries, err := os.ReadDir(srcDir)
// 	if err != nil {
// 		panic(err)
// 	}

// 	for _, entry := range entries {
// 		if entry.IsDir() {
// 			continue // skip subdirectories
// 		}

// 		srcPath := filepath.Join(srcDir, entry.Name())
// 		dstPath := filepath.Join(dstDir, entry.Name())

// 		if err := os.Rename(srcPath, dstPath); err != nil {
// 			fmt.Printf("Failed to move %s: %v\n", entry.Name(), err)
// 			continue
// 		}

// 		fmt.Printf("Moved %s\n", entry.Name())
// 	}
// }
