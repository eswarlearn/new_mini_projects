export const CON_URL = 
"https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_208,h_208,c_fit/";

export const LOGO_URL = 
"https://img.freepik.com/premium-vector/indian-restaurant-icon-elephant-spice-leaf_8071-48367.jpg?w=740";

export const MENU_API ="https://www.swiggy.com/dapi/menu/pl?page-type=REGULAR_MENU&complete-menu=true&lat=12.89960&lng=80.22090&restaurantId=";