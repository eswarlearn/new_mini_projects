# React 

# Parcel
- Dev Build
- Local Server
- HMR = Hard Module Replacement
- File waatching algorithm - written in c++
- Catching - Faster Buildinds
- Image optimization
- Minification 
- Bundling
- Compress
- Consistent Hashing
- Code Splitting
- Differential Bundling - support older browsers
- Diagnostic
- Error handling
- can host on http and https
- Tree Shaking - remove the unused code
- Different dev and prod bundler

# Vanakam 
/*
* Header
* - Logo
* -Nav Iteams
* Body
* - Search 
* - RestaurantContainer
*   -- RestaurantCard
*   -- Img
*   -- Name of rest , star rating, cusine, deteils
* Footer
* -Link
* -Contach
* -Adress 
* -CopyRights 
*/